#ifdef __APPLE__
# include "gccxml_apple_mmintrin.h"
#else
# include "gccxml_gnu_mmintrin.h"
#endif
