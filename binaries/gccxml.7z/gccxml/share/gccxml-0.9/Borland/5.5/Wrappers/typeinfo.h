#if defined(__USING_STD_NAMES__)
# undef __USING_STD_NAMES__
# include <gccxml_typeinfo.h>
# define __USING_STD_NAMES__
#else
# include <gccxml_typeinfo.h>
#endif
