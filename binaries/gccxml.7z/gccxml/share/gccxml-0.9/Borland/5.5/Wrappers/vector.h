#if defined(__USING_STD_NAMES__)
# undef __USING_STD_NAMES__
# include <gccxml_vector.h>
# define __USING_STD_NAMES__
#else
# include <gccxml_vector.h>
#endif
